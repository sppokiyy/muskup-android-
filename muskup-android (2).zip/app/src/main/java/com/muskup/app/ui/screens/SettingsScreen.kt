package com.muskup.app.ui.screens

import androidx.appcompat.app.AppCompatDelegate
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.os.LocaleListCompat
import com.muskup.app.BuildConfig
import com.muskup.app.R
import com.muskup.app.data.DEFAULT_SERVER
import com.muskup.app.data.SettingsStore
import com.muskup.app.ui.*
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen(store: SettingsStore) {
    val scope = rememberCoroutineScope()
    val theme by store.theme.collectAsState(initial = "purple")
    val server by store.server.collectAsState(initial = "")
    var serverText by remember(server) { mutableStateOf(server) }
    var lang by remember {
        mutableStateOf(AppCompatDelegate.getApplicationLocales().toLanguageTags().ifEmpty { "uk" }.take(2))
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Text(stringResource(R.string.tab_settings), fontSize = 24.sp, fontWeight = FontWeight.Bold, color = TextMain)

        MuskCard(Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.set_server), color = TextMuted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                serverText, { serverText = it; scope.launch { store.setServer(it) } },
                placeholder = { Text("wss://muskup-signal.XXX.workers.dev") },
                singleLine = true, modifier = Modifier.fillMaxWidth(),
            )
            TextButton({ serverText = DEFAULT_SERVER; scope.launch { store.setServer(DEFAULT_SERVER) } }) {
                Text(stringResource(R.string.set_server_reset), color = LocalAccent.current.c2)
            }
        }

        MuskCard(Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.set_theme), color = TextMuted, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Accent.values().forEach { a ->
                    val sel = a.key == theme
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(a.brush)
                            .then(if (sel) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                            .clickable { scope.launch { store.setTheme(a.key) } }
                    )
                }
            }
        }

        MuskCard(Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.set_language), color = TextMuted, fontSize = 13.sp)
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                listOf("uk" to "Українська", "en" to "English").forEach { (code, name) ->
                    val sel = lang == code
                    Box(
                        Modifier.clip(RoundedCornerShape(14.dp))
                            .background(if (sel) LocalAccent.current.c1 else Panel)
                            .clickable {
                                lang = code
                                AppCompatDelegate.setApplicationLocales(LocaleListCompat.forLanguageTags(code))
                            }.padding(horizontal = 18.dp, vertical = 12.dp)
                    ) { Text(name, color = TextMain) }
                }
            }
        }

        MuskCard(Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.about), color = TextMain, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(4.dp))
            Text(stringResource(R.string.version, BuildConfig.VERSION_NAME), color = TextMuted, fontSize = 13.sp)
        }
    }
}
