package com.muskup.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.muskup.app.R
import com.muskup.app.data.HistoryStore
import com.muskup.app.data.formatId
import com.muskup.app.ui.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private fun statusInfo(s: String): Pair<Int, Color> = when (s) {
    "ok" -> R.string.hist_ok to OnlineGreen
    "rejected" -> R.string.hist_rejected to Color(0xFFEF4444)
    "badpass" -> R.string.hist_badpass to Color(0xFFEF4444)
    "busy" -> R.string.hist_busy to Color(0xFFFACC15)
    "offline" -> R.string.hist_offline to Color(0xFFFACC15)
    else -> R.string.hist_attempt to TextMuted
}

@Composable
fun HistoryScreen(store: HistoryStore, onReconnect: (String) -> Unit) {
    val scope = rememberCoroutineScope()
    val items by store.items.collectAsState(initial = emptyList())
    val fmt = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault()) }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.hist_title), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextMain, modifier = Modifier.weight(1f))
            if (items.isNotEmpty()) TextButton({ scope.launch { store.clear() } }) {
                Text(stringResource(R.string.hist_clear), color = LocalAccent.current.c2)
            }
        }
        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text(stringResource(R.string.hist_empty), color = TextMuted, textAlign = TextAlign.Center)
            }
        } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(items) { h ->
                val (label, color) = statusInfo(h.status)
                MuskCard(Modifier.fillMaxWidth(), onClick = { onReconnect(h.id) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(painterResource(R.drawable.ic_monitor), null, tint = TextMain, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(formatId(h.id), color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                            Text(fmt.format(Date(h.ts)), color = TextMuted, fontSize = 12.sp)
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(8.dp).clip(CircleShape).background(color))
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(label), color = color, fontSize = 12.sp)
                        }
                    }
                }
            }
        }
    }
}
