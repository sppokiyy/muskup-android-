package com.muskup.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

/** status: attempt | ok | rejected | badpass | busy | offline. Пароль НІКОЛИ не зберігається. */
@Serializable
data class HistoryItem(val id: String, val ts: Long, val status: String)

fun formatId(s: String) = s.chunked(3).joinToString(" ")

class HistoryStore(private val ctx: Context) {
    private val key = stringPreferencesKey("history")
    private val json = Json { ignoreUnknownKeys = true }

    val items: Flow<List<HistoryItem>> = ctx.dataStore.data.map { p ->
        p[key]?.let { runCatching { json.decodeFromString<List<HistoryItem>>(it) }.getOrNull() } ?: emptyList()
    }

    suspend fun add(id: String, status: String) {
        ctx.dataStore.edit { p ->
            val cur = p[key]?.let { runCatching { json.decodeFromString<List<HistoryItem>>(it) }.getOrNull() } ?: emptyList()
            p[key] = json.encodeToString((listOf(HistoryItem(id, System.currentTimeMillis(), status)) + cur).take(100))
        }
    }

    suspend fun clear() { ctx.dataStore.edit { it.remove(key) } }
}
