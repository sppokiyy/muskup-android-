package com.muskup.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.muskup.app.R

val Bg = Color(0xFF000000)
val Panel = Color(0xFF08080D)
val CardBg = Color(0xFF0D0D14)
val Border = Color(0xFF1A1A25)
val TextMain = Color(0xFFF4F4F8)
val TextMuted = Color(0xFF8B8B9C)
val OnlineGreen = Color(0xFF22C55E)

enum class Accent(val key: String, val label: Int, val c1: Color, val c2: Color) {
    Purple("purple", R.string.theme_purple, Color(0xFF4A2BE0), Color(0xFF6D4AFF)),
    Blue("blue", R.string.theme_blue, Color(0xFF1D4ED8), Color(0xFF3B82F6)),
    Green("green", R.string.theme_green, Color(0xFF15803D), Color(0xFF22C55E)),
    Red("red", R.string.theme_red, Color(0xFFB91C1C), Color(0xFFEF4444)),
    Yellow("yellow", R.string.theme_yellow, Color(0xFFCA8A04), Color(0xFFFACC15)),
    Gray("gray", R.string.theme_gray, Color(0xFF52525B), Color(0xFF8B8B9C));

    val brush get() = Brush.linearGradient(listOf(c1, c2))
    companion object { fun of(k: String) = values().firstOrNull { it.key == k } ?: Purple }
}

val LocalAccent = compositionLocalOf { Accent.Purple }

@Composable
fun MuskupTheme(accent: Accent, content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = accent.c2, onPrimary = Color.White,
        background = Bg, onBackground = TextMain,
        surface = CardBg, onSurface = TextMain, onSurfaceVariant = TextMuted,
        outline = Border,
    )
    CompositionLocalProvider(LocalAccent provides accent) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}
