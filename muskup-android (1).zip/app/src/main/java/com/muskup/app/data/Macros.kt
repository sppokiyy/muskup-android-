package com.muskup.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.muskup.app.R
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

/** Крок швидкої команди. Формат полів збігається з Windows-версією. */
@Serializable
data class MacroStep(
    val type: String,
    val combo: String? = null,
    val text: String? = null,
    val ms: Int? = null,
    val x: Int? = null,
    val y: Int? = null,
    val button: String? = null,
    val double: Boolean? = null,
    val target: String? = null,
    val url: String? = null,
)

@Serializable
data class Macro(
    val id: String,
    val name: String,
    val icon: String = "⚡",
    val color: String = "#6d4aff",
    val steps: List<MacroStep> = emptyList(),
)

/** Файл експорту/імпорту: {"muskup":1,"macros":[...]} */
@Serializable
data class MacroFile(val muskup: Int = 1, val macros: List<Macro>)

@OptIn(ExperimentalSerializationApi::class)
object MacroJson {
    private val json = Json {
        ignoreUnknownKeys = true
        explicitNulls = false
        encodeDefaults = true
        prettyPrint = true
    }

    fun encode(list: List<Macro>): String = json.encodeToString(MacroFile(1, list))
    fun decode(s: String): List<Macro> = json.decodeFromString<MacroFile>(s).macros.map { sanitize(it) }

    /** Обмеження протоколу: ≤100 кроків, text ≤500, wait 0..30000, click 0..100. */
    fun sanitize(m: Macro): Macro = m.copy(
        id = m.id.ifBlank { newId() },
        name = m.name.take(60),
        steps = m.steps.take(100).map { s ->
            s.copy(
                text = s.text?.take(500),
                ms = s.ms?.coerceIn(0, 30000),
                x = s.x?.coerceIn(0, 100),
                y = s.y?.coerceIn(0, 100),
            )
        },
    )

    fun newId() = UUID.randomUUID().toString().take(8)
}

fun MacroStep.summary(): String = when (type) {
    "key" -> "⌨  $combo"
    "text" -> "Aa  «${text.orEmpty().take(40)}»"
    "wait" -> "⏱  ${ms ?: 0} мс"
    "click" -> "🖱  ${x ?: 50}%, ${y ?: 50}%  ${button ?: "left"}${if (double == true) " ×2" else ""}"
    "run" -> "▶  $target"
    "url" -> "🌐  $url"
    else -> type
}

fun macroTemplates(ctx: Context): List<Macro> {
    fun m(name: Int, icon: String, color: String, vararg steps: MacroStep) =
        Macro(MacroJson.newId(), ctx.getString(name), icon, color, steps.toList())
    fun key(c: String) = MacroStep("key", combo = c)
    fun run(t: String) = MacroStep("run", target = t)
    fun winR(cmd: String) = arrayOf(key("Win+R"), MacroStep("wait", ms = 300), MacroStep("text", text = cmd), key("Enter"))
    return listOf(
        m(R.string.tpl_cmd, "⌨", "#4a2be0", *winR("cmd")),
        m(R.string.tpl_ps, "🟦", "#1d4ed8", *winR("powershell")),
        m(R.string.tpl_tm, "📊", "#15803d", key("Ctrl+Shift+Esc")),
        m(R.string.tpl_explorer, "📁", "#ca8a04", key("Win+E")),
        m(R.string.tpl_settings, "⚙", "#52525b", key("Win+I")),
        m(R.string.tpl_lock, "🔒", "#b91c1c", run("rundll32.exe user32.dll,LockWorkStation")),
        m(R.string.tpl_desktop, "🖥", "#6d4aff", key("Win+D")),
        m(R.string.tpl_notepad, "📝", "#3b82f6", run("notepad")),
        m(R.string.tpl_shot, "✂", "#22c55e", key("Win+Shift+S")),
        m(R.string.tpl_youtube, "▶", "#ef4444", MacroStep("url", url = "https://www.youtube.com")),
        m(R.string.tpl_google, "🔍", "#3b82f6", MacroStep("url", url = "https://www.google.com")),
    )
}

class MacroStore(private val ctx: Context) {
    private val key = stringPreferencesKey("macros")

    /** Поки користувач нічого не зберігав, показуємо шаблони. */
    val macros: Flow<List<Macro>> = ctx.dataStore.data.map { p ->
        p[key]?.let { runCatching { MacroJson.decode(it) }.getOrNull() } ?: macroTemplates(ctx)
    }

    suspend fun save(list: List<Macro>) { ctx.dataStore.edit { it[key] = MacroJson.encode(list) } }
}
