package com.muskup.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.muskup.app.R
import com.muskup.app.data.MacroStore
import com.muskup.app.data.SettingsStore
import com.muskup.app.ui.screens.HomeScreen
import com.muskup.app.ui.screens.MacrosScreen
import com.muskup.app.ui.screens.SettingsScreen

enum class Tab(val label: Int, val icon: Int) {
    Desktop(R.string.tab_desktop, R.drawable.ic_monitor),
    Contacts(R.string.tab_contacts, R.drawable.ic_users),
    Macros(R.string.tab_macros, R.drawable.ic_bolt),
    History(R.string.tab_history, R.drawable.ic_clock),
    Settings(R.string.tab_settings, R.drawable.ic_gear)
}

@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val store = remember { SettingsStore(ctx) }
    val macroStore = remember { MacroStore(ctx) }
    val themeKey by store.theme.collectAsState(initial = "purple")
    var tab by remember { mutableStateOf(Tab.Desktop) }

    MuskupTheme(Accent.of(themeKey)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    Tab.values().forEach { t ->
                        NavigationBarItem(
                            selected = tab == t, onClick = { tab = t },
                            icon = { Icon(painterResource(t.icon), null, Modifier.size(24.dp)) },
                            label = { Text(stringResource(t.label), fontSize = 10.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = TextMain, selectedTextColor = TextMain,
                                unselectedIconColor = TextMuted, unselectedTextColor = TextMuted,
                                indicatorColor = LocalAccent.current.c1.copy(alpha = 0.40f)),
                        )
                    }
                }
            },
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize().background(Bg)) {
                when (tab) {
                    Tab.Desktop -> HomeScreen(onOpenSettings = { tab = Tab.Settings }, onOpenHistory = { tab = Tab.History })
                    Tab.Macros -> MacrosScreen(macroStore)
                    Tab.Settings -> SettingsScreen(store)
                    else -> Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                        Text(stringResource(R.string.soon), color = TextMuted, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}
