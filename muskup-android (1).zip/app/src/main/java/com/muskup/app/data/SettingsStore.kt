package com.muskup.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

internal val Context.dataStore by preferencesDataStore("settings")

class SettingsStore(private val ctx: Context) {
    private val themeKey = stringPreferencesKey("theme")
    private val serverKey = stringPreferencesKey("server")

    val theme: Flow<String> = ctx.dataStore.data.map { it[themeKey] ?: "purple" }
    val server: Flow<String> = ctx.dataStore.data.map { it[serverKey] ?: "" }

    suspend fun setTheme(v: String) { ctx.dataStore.edit { it[themeKey] = v } }
    suspend fun setServer(v: String) { ctx.dataStore.edit { it[serverKey] = v.trim() } }
}
