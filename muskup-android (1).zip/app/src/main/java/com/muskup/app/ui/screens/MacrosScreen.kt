package com.muskup.app.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.muskup.app.R
import com.muskup.app.data.*
import com.muskup.app.ui.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val Palette = listOf("#4a2be0", "#6d4aff", "#1d4ed8", "#3b82f6", "#15803d", "#22c55e", "#b91c1c", "#ef4444", "#ca8a04", "#facc15", "#52525b", "#8b8b9c")
private fun parse(hex: String) = runCatching { Color(android.graphics.Color.parseColor(hex)) }.getOrDefault(Color(0xFF6D4AFF))

@Composable
fun MacrosScreen(store: MacroStore) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val list by store.macros.collectAsState(initial = emptyList())
    var editing by remember { mutableStateOf<Macro?>(null) }
    var showAdd by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf<String?>(null) }

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch {
            val ok = withContext(Dispatchers.IO) {
                runCatching { ctx.contentResolver.openOutputStream(uri)?.use { it.write(MacroJson.encode(list).toByteArray()) } }.isSuccess
            }
            msg = if (ok) ctx.getString(R.string.macros_export_ok) else ctx.getString(R.string.macros_import_err)
        }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            val res = withContext(Dispatchers.IO) {
                runCatching { MacroJson.decode(ctx.contentResolver.openInputStream(uri)!!.bufferedReader().readText()) }
            }
            res.onSuccess { imported ->
                val ids = imported.map { it.id }.toSet()
                store.save(list.filter { it.id !in ids } + imported)
                msg = ctx.getString(R.string.macros_import_ok, imported.size)
            }.onFailure { msg = ctx.getString(R.string.macros_import_err) }
        }
    }

    val cur = editing
    if (cur != null) {
        val m = cur
        MacroEditor(
            initial = m,
            onCancel = { editing = null },
            onDelete = { scope.launch { store.save(list.filter { it.id != m.id }) }; editing = null },
            onSave = { saved ->
                scope.launch { store.save(if (list.any { it.id == saved.id }) list.map { if (it.id == saved.id) saved else it } else list + saved) }
                editing = null
            },
        )
        return
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(stringResource(R.string.macros_title), fontSize = 22.sp, fontWeight = FontWeight.Bold, color = TextMain, modifier = Modifier.weight(1f))
            IconButton({ importer.launch(arrayOf("application/json", "text/plain", "*/*")) }) { Icon(painterResource(R.drawable.ic_import), null, tint = TextMuted) }
            IconButton({ exporter.launch("muskup-commands.json") }) { Icon(painterResource(R.drawable.ic_export), null, tint = TextMuted) }
            IconButton({ showAdd = true }) { Icon(Icons.Default.Add, null, tint = LocalAccent.current.c2) }
        }
        msg?.let { Banner(it, LocalAccent.current.c2) }
        LazyVerticalGrid(GridCells.Fixed(2), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list, key = { it.id }) { m ->
                MuskCard(Modifier.fillMaxWidth(), onClick = { msg = ctx.getString(R.string.macros_run_hint) }) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
                        Box(Modifier.size(44.dp).clip(CircleShape).background(parse(m.color).copy(alpha = 0.25f)), Alignment.Center) { Text(m.icon, fontSize = 22.sp) }
                        Spacer(Modifier.weight(1f))
                        Icon(Icons.Default.Edit, null, tint = TextMuted, modifier = Modifier.size(20.dp).clickable { editing = m })
                    }
                    Spacer(Modifier.height(10.dp))
                    Text(m.name, color = TextMain, fontWeight = FontWeight.SemiBold, maxLines = 2)
                    Text("${m.steps.size}", color = TextMuted, fontSize = 12.sp)
                }
            }
        }
    }

    if (showAdd) AlertDialog(
        onDismissRequest = { showAdd = false }, containerColor = CardBg,
        title = { Text(stringResource(R.string.macros_new), color = TextMain) },
        text = {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                item {
                    TextButton({ showAdd = false; editing = Macro(MacroJson.newId(), "", "⚡", "#6d4aff") }) { Text(stringResource(R.string.macro_empty)) }
                }
                items(macroTemplates(ctx)) { t ->
                    TextButton({ showAdd = false; editing = t }) { Text("${t.icon}  ${t.name}", color = TextMain) }
                }
            }
        },
        confirmButton = { TextButton({ showAdd = false }) { Text(stringResource(R.string.cancel), color = TextMuted) } },
    )
}

@Composable
private fun MacroEditor(initial: Macro, onCancel: () -> Unit, onDelete: () -> Unit, onSave: (Macro) -> Unit) {
    var name by remember { mutableStateOf(initial.name) }
    var icon by remember { mutableStateOf(initial.icon) }
    var color by remember { mutableStateOf(initial.color) }
    val steps = remember { mutableStateListOf<MacroStep>().apply { addAll(initial.steps) } }
    var stepEdit by remember { mutableStateOf<Pair<Int, MacroStep?>?>(null) }
    var limitMsg by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onCancel) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = TextMain) }
                Spacer(Modifier.weight(1f))
                IconButton(onDelete) { Icon(Icons.Default.Delete, null, tint = Color(0xFFEF4444)) }
                GradientButton(stringResource(R.string.macro_save), Modifier.width(130.dp)) {
                    onSave(MacroJson.sanitize(Macro(initial.id, name.ifBlank { "—" }, icon.ifBlank { "⚡" }, color, steps.toList())))
                }
            }
        }
        item {
            OutlinedTextField(name, { name = it.take(60) }, label = { Text(stringResource(R.string.macro_name)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        item {
            OutlinedTextField(icon, { icon = it.take(4) }, label = { Text(stringResource(R.string.macro_icon)) }, singleLine = true, modifier = Modifier.fillMaxWidth())
        }
        item {
            Text(stringResource(R.string.macro_color), color = TextMuted, fontSize = 13.sp)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Palette.forEach { c ->
                    Box(Modifier.size(34.dp).clip(CircleShape).background(parse(c))
                        .then(if (c.equals(color, true)) Modifier.border(2.dp, Color.White, CircleShape) else Modifier)
                        .clickable { color = c })
                }
            }
        }
        item { Text("${stringResource(R.string.macro_steps)} (${steps.size}/100)", color = TextMain, fontWeight = FontWeight.SemiBold) }
        itemsIndexed(steps) { i, s ->
            MuskCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(s.summary(), color = TextMain, modifier = Modifier.weight(1f), maxLines = 2)
                    Text("▲", color = if (i > 0) TextMuted else Border, modifier = Modifier.clickable(enabled = i > 0) { val t = steps.removeAt(i); steps.add(i - 1, t) }.padding(8.dp))
                    Text("▼", color = if (i < steps.lastIndex) TextMuted else Border, modifier = Modifier.clickable(enabled = i < steps.lastIndex) { val t = steps.removeAt(i); steps.add(i + 1, t) }.padding(8.dp))
                    Icon(Icons.Default.Edit, null, tint = TextMuted, modifier = Modifier.clickable { stepEdit = i to s }.padding(6.dp))
                    Icon(Icons.Default.Delete, null, tint = TextMuted, modifier = Modifier.clickable { steps.removeAt(i) }.padding(6.dp))
                }
            }
        }
        item {
            if (limitMsg) Banner(stringResource(R.string.macro_steps_limit), Color(0xFFFACC15))
            Spacer(Modifier.height(8.dp))
            GradientButton(stringResource(R.string.macro_add_step), Modifier.fillMaxWidth()) {
                if (steps.size >= 100) limitMsg = true else stepEdit = steps.size to null
            }
            Spacer(Modifier.height(24.dp))
        }
    }

    stepEdit?.let { (idx, s) ->
        StepDialog(s, onDismiss = { stepEdit = null }) { ns ->
            if (s == null) steps.add(ns) else steps[idx] = ns
            stepEdit = null
        }
    }
}

@Composable
private fun StepDialog(initial: MacroStep?, onDismiss: () -> Unit, onOk: (MacroStep) -> Unit) {
    var type by remember { mutableStateOf(initial?.type ?: "key") }
    var combo by remember { mutableStateOf(initial?.combo ?: "") }
    var text by remember { mutableStateOf(initial?.text ?: "") }
    var ms by remember { mutableStateOf((initial?.ms ?: 300).toString()) }
    var x by remember { mutableStateOf((initial?.x ?: 50).toString()) }
    var y by remember { mutableStateOf((initial?.y ?: 50).toString()) }
    var button by remember { mutableStateOf(initial?.button ?: "left") }
    var dbl by remember { mutableStateOf(initial?.double ?: false) }
    var target by remember { mutableStateOf(initial?.target ?: "") }
    var url by remember { mutableStateOf(initial?.url ?: "https://") }
    val num = KeyboardOptions(keyboardType = KeyboardType.Number)

    AlertDialog(
        onDismissRequest = onDismiss, containerColor = CardBg,
        title = {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("key", "text", "wait", "click", "run", "url").forEach { t ->
                    FilterChip(type == t, { type = t }, label = { Text(t) })
                }
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                when (type) {
                    "key" -> OutlinedTextField(combo, { combo = it }, label = { Text(stringResource(R.string.f_combo)) }, singleLine = true)
                    "text" -> OutlinedTextField(text, { text = it.take(500) }, label = { Text(stringResource(R.string.f_text)) })
                    "wait" -> OutlinedTextField(ms, { ms = it.filter(Char::isDigit).take(5) }, label = { Text(stringResource(R.string.f_ms)) }, singleLine = true, keyboardOptions = num)
                    "click" -> {
                        OutlinedTextField(x, { x = it.filter(Char::isDigit).take(3) }, label = { Text(stringResource(R.string.f_x)) }, singleLine = true, keyboardOptions = num)
                        OutlinedTextField(y, { y = it.filter(Char::isDigit).take(3) }, label = { Text(stringResource(R.string.f_y)) }, singleLine = true, keyboardOptions = num)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("left", "right").forEach { b -> FilterChip(button == b, { button = b }, label = { Text(b) }) }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Switch(dbl, { dbl = it }); Spacer(Modifier.width(10.dp)); Text(stringResource(R.string.f_double), color = TextMain)
                        }
                    }
                    "run" -> OutlinedTextField(target, { target = it }, label = { Text(stringResource(R.string.f_run)) }, singleLine = true)
                    "url" -> OutlinedTextField(url, { url = it }, label = { Text(stringResource(R.string.f_url)) }, singleLine = true)
                }
            }
        },
        confirmButton = {
            TextButton({
                onOk(when (type) {
                    "key" -> MacroStep("key", combo = combo.trim())
                    "text" -> MacroStep("text", text = text)
                    "wait" -> MacroStep("wait", ms = (ms.toIntOrNull() ?: 0).coerceIn(0, 30000))
                    "click" -> MacroStep("click", x = (x.toIntOrNull() ?: 50).coerceIn(0, 100), y = (y.toIntOrNull() ?: 50).coerceIn(0, 100), button = button, double = dbl)
                    "run" -> MacroStep("run", target = target.trim())
                    else -> MacroStep("url", url = url.trim())
                })
            }) { Text(stringResource(R.string.ok)) }
        },
        dismissButton = { TextButton(onDismiss) { Text(stringResource(R.string.cancel), color = TextMuted) } },
    )
}
