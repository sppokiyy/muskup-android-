package com.muskup.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.muskup.app.R
import com.muskup.app.ui.*

/** 123456789 -> "123 456 789" */
class IdTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val t = text.text
        val out = buildString { t.forEachIndexed { i, c -> if (i == 3 || i == 6) append(' '); append(c) } }
        val map = object : OffsetMapping {
            override fun originalToTransformed(offset: Int) = offset + if (offset > 6) 2 else if (offset > 3) 1 else 0
            override fun transformedToOriginal(offset: Int) = if (offset > 7) offset - 2 else if (offset > 3) offset - 1 else offset
        }
        return TransformedText(AnnotatedString(out), map)
    }
}

@Composable
fun HomeScreen(onOpenSettings: () -> Unit, onOpenHistory: () -> Unit) {
    var showDialog by remember { mutableStateOf(false) }
    var banner by remember { mutableStateOf<String?>(null) }
    val stage = stringResource(R.string.banner_stage)
    val accent = LocalAccent.current

    Box(
        Modifier.fillMaxSize().background(
            Brush.radialGradient(listOf(accent.c1.copy(alpha = 0.22f), Color.Transparent), center = Offset(0f, 0f), radius = 1100f)
        )
    ) {
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(OnlineGreen))
                Spacer(Modifier.width(7.dp))
                Text(stringResource(R.string.online), color = TextMain, fontSize = 13.sp)
            }
            Image(painterResource(R.drawable.logo_full), null, Modifier.height(150.dp), contentScale = ContentScale.Fit)
            Spacer(Modifier.height(2.dp))
            Text(stringResource(R.string.tagline1a), fontSize = 28.sp, fontWeight = FontWeight.SemiBold, color = TextMain, textAlign = TextAlign.Center, lineHeight = 32.sp)
            Text(stringResource(R.string.tagline1b), fontSize = 28.sp, color = TextMuted, textAlign = TextAlign.Center, lineHeight = 32.sp)
            Text(stringResource(R.string.tagline2), color = TextMuted, fontSize = 14.sp)

            banner?.let { Banner(it, Color(0xFFFACC15)) }

            MuskCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(painterResource(R.drawable.ic_monitor), null, tint = TextMain, modifier = Modifier.size(52.dp))
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(stringResource(R.string.desktop_card), color = TextMain, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                        Text(stringResource(R.string.desktop_desc), color = TextMuted, fontSize = 13.sp, lineHeight = 17.sp)
                    }
                }
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(
                        Modifier.weight(1f).height(52.dp).clip(RoundedCornerShape(16.dp)).background(accent.brush)
                            .clickable { showDialog = true },
                        contentAlignment = Alignment.Center,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(painterResource(R.drawable.ic_monitor), null, tint = Color.White, modifier = Modifier.size(22.dp))
                            Spacer(Modifier.width(10.dp))
                            Text(stringResource(R.string.connect), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
                        }
                    }
                    Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Panel).clickable(onClick = onOpenHistory),
                        contentAlignment = Alignment.Center,
                    ) { Icon(painterResource(R.drawable.ic_swap), null, tint = TextMain, modifier = Modifier.size(22.dp)) }
                }
            }

            FeatureCard(R.drawable.ic_users, R.string.tile_identity, R.string.tile_identity_desc, R.string.tile_identity_link) { banner = stage }
            FeatureCard(R.drawable.ic_shield, R.string.tile_security, R.string.tile_security_desc, R.string.tile_security_link) { banner = stage }
            FeatureCard(R.drawable.ic_gear, R.string.tile_settings, R.string.tile_settings_desc, R.string.tile_settings_link, onOpenSettings)
        }
    }

    if (showDialog) ConnectDialog(onDismiss = { showDialog = false }) { _, _ ->
        showDialog = false; banner = stage
    }
}

@Composable
private fun FeatureCard(icon: Int, title: Int, desc: Int, link: Int, onClick: () -> Unit) {
    val accent = LocalAccent.current
    MuskCard(Modifier.fillMaxWidth(), onClick) {
        Row(verticalAlignment = Alignment.Top) {
            Icon(painterResource(icon), null, tint = TextMain, modifier = Modifier.size(36.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(stringResource(title), color = TextMain, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(stringResource(desc), color = TextMuted, fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(stringResource(link), color = accent.c2, fontSize = 14.sp)
                    Spacer(Modifier.width(6.dp))
                    Icon(painterResource(R.drawable.ic_arrow), null, tint = accent.c2, modifier = Modifier.size(16.dp))
                }
            }
        }
    }
}

@Composable
fun ConnectDialog(onDismiss: () -> Unit, onConnect: (String, String) -> Unit) {
    var id by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text(stringResource(R.string.connect_title), color = TextMain) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    id, { v -> id = v.filter { it.isDigit() }.take(9) },
                    label = { Text(stringResource(R.string.field_id)) }, singleLine = true,
                    visualTransformation = IdTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                OutlinedTextField(
                    pass, { pass = it },
                    label = { Text(stringResource(R.string.field_pass)) }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConnect(id, pass) }, enabled = id.length == 9 && pass.isNotEmpty()) {
                Text(stringResource(R.string.connect))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = TextMuted) } },
    )
}
