plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.serialization")
}

android {
    namespace = "com.muskup.app"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.muskup.app"
        minSdk = 26
        targetSdk = 34
        versionCode = (project.findProperty("appCode") as String?)?.toInt() ?: 1
        versionName = (project.findProperty("appVersion") as String?) ?: "0.1.0"
    }
    signingConfigs {
        // ТИМЧАСОВО (MVP): keystore у репозиторії. Перед публічним релізом замінити
        // на секрети GitHub Actions і НЕ втрачати ключ, інакше оновлення поверх не поставляться.
        create("muskup") {
            storeFile = file("muskup-temp.jks")
            storePassword = "muskup-temp"
            keyAlias = "muskup"
            keyPassword = "muskup-temp"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("muskup")
        }
    }
    buildFeatures { compose = true; buildConfig = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    implementation("org.jetbrains.kotlinx:kotlinx-serialization-json:1.6.3")
}
