package com.muskup.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.muskup.app.R
import com.muskup.app.data.SettingsStore
import com.muskup.app.ui.screens.HomeScreen
import com.muskup.app.ui.screens.SettingsScreen

enum class Tab(val label: Int, val icon: String) {
    Desktop(R.string.tab_desktop, "🖥"),   // іконки-емодзі: тимчасові
    Contacts(R.string.tab_contacts, "👤"),
    Macros(R.string.tab_macros, "⚡"),
    History(R.string.tab_history, "🕘"),
    Settings(R.string.tab_settings, "⚙")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot() {
    val ctx = LocalContext.current
    val store = remember { SettingsStore(ctx) }
    val themeKey by store.theme.collectAsState(initial = "purple")
    var tab by remember { mutableStateOf(Tab.Desktop) }

    MuskupTheme(Accent.of(themeKey)) {
        Scaffold(
            containerColor = Bg,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    Tab.values().forEach { t ->
                        NavigationBarItem(
                            selected = tab == t, onClick = { tab = t },
                            icon = { Text(t.icon, fontSize = 20.sp) },
                            label = { Text(stringResource(t.label), fontSize = 9.sp, maxLines = 1) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedTextColor = TextMain, unselectedTextColor = TextMuted,
                                indicatorColor = LocalAccent.current.c1.copy(alpha = 0.35f)),
                        )
                    }
                }
            },
        ) { pad ->
            Box(Modifier.padding(pad).fillMaxSize().background(Bg)) {
                when (tab) {
                    Tab.Desktop -> HomeScreen(onOpenSettings = { tab = Tab.Settings }, onOpenHistory = { tab = Tab.History })
                    Tab.Settings -> SettingsScreen(store)
                    else -> Box(Modifier.fillMaxSize().padding(32.dp), Alignment.Center) {
                        Text(stringResource(R.string.soon), color = TextMuted, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}
