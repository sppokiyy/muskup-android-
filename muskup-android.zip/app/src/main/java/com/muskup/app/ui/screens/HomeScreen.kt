package com.muskup.app.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.muskup.app.R
import com.muskup.app.ui.*

/** 123456789 -> "123 456 789" */
class IdTransformation : VisualTransformation {
    override fun filter(text: AnnotatedString): TransformedText {
        val t = text.text
        val out = buildString { t.forEachIndexed { i, c -> if (i == 3 || i == 6) append(' '); append(c) } }
        val map = object : OffsetMapping {
            override fun originalToTransformed(offset: Int) = offset + if (offset > 6) 2 else if (offset > 3) 1 else 0
            override fun transformedToOriginal(offset: Int) = if (offset > 7) offset - 2 else if (offset > 3) offset - 1 else offset
        }
        return TransformedText(AnnotatedString(out), map)
    }
}

@Composable
fun HomeScreen(onOpenSettings: () -> Unit, onOpenHistory: () -> Unit) {
    var showDialog by remember { mutableStateOf(false) }
    var banner by remember { mutableStateOf<String?>(null) }
    val stage = stringResource(R.string.banner_stage)

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Image(painterResource(R.drawable.logo_mark), null, Modifier.size(112.dp))
        Text("MUSKUP", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = TextMain)
        Text(stringResource(R.string.tagline1), color = TextMain, fontSize = 16.sp, textAlign = TextAlign.Center)
        Text(stringResource(R.string.tagline2), color = TextMuted, fontSize = 14.sp)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.size(10.dp).clip(CircleShape).background(OnlineGreen))
            Text(stringResource(R.string.online), color = OnlineGreen, fontSize = 13.sp)
        }

        banner?.let { Banner(it, Color(0xFFFACC15)) }

        MuskCard(Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.desktop_card), color = TextMain, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GradientButton(stringResource(R.string.connect), Modifier.weight(1f)) { showDialog = true }
                Box(
                    Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(Panel)
                        .clickable(onClick = onOpenHistory), contentAlignment = Alignment.Center
                ) { Text("🕘", fontSize = 20.sp) }
            }
        }

        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Tile("🪪", R.string.tile_identity, Modifier.weight(1f)) {}
            Tile("🔒", R.string.tile_security, Modifier.weight(1f)) {}
            Tile("⚙", R.string.tile_settings, Modifier.weight(1f), onOpenSettings)
        }
    }

    if (showDialog) ConnectDialog(onDismiss = { showDialog = false }) { _, _ ->
        showDialog = false; banner = stage
    }
}

@Composable
private fun Tile(icon: String, label: Int, modifier: Modifier, onClick: () -> Unit) {
    MuskCard(modifier, onClick) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 24.sp)
            Spacer(Modifier.height(6.dp))
            Text(stringResource(label), color = TextMain, fontSize = 11.sp, maxLines = 1, textAlign = TextAlign.Center)
        }
    }
}

@Composable
fun ConnectDialog(onDismiss: () -> Unit, onConnect: (String, String) -> Unit) {
    var id by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CardBg,
        title = { Text(stringResource(R.string.connect_title), color = TextMain) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    id, { v -> id = v.filter { it.isDigit() }.take(9) },
                    label = { Text(stringResource(R.string.field_id)) }, singleLine = true,
                    visualTransformation = IdTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                )
                OutlinedTextField(
                    pass, { pass = it },
                    label = { Text(stringResource(R.string.field_pass)) }, singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConnect(id, pass) }, enabled = id.length == 9 && pass.isNotEmpty()) {
                Text(stringResource(R.string.connect))
            }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text(stringResource(R.string.cancel), color = TextMuted) } },
    )
}
